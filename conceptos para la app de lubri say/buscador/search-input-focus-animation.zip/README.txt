A Pen created at CodePen.io. You can find this one at https://codepen.io/nicolasjengler/pen/ZGqjGV.

 A simple animation for the focus event on a search input.